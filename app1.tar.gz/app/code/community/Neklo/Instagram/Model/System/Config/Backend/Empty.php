<?php

class Neklo_Instagram_Model_System_Config_Backend_Empty extends Mage_Core_Model_Config_Data
{
    public function getValue()
    {
        return null;
    }
}
